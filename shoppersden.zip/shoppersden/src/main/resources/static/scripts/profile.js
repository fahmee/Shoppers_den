$(document).ready(function(){
	var bname=$('#name').val();
	var bmob=$('#mobile').val();
	$('#chgdetails').click(function(){
		var aname=$('#name').val();
		var amob=$('#mobile').val();
		if(bname!=aname||bmob!=amob)
			{
			
			}else
				{
				alert("you haven't change anythings");
				}
	});
	
	$('#cnfpass').keyup(function(){
		var npass=$('#npass').val();
		var cnfpass=$(this).val();
		if(npass!=cnfpass)
			{
			$('#errmsg').show();
			}
		else{
			$('#errmsg').hide();
		}
	});
	
	
    $('#chgpass').click(function() {
      $('#chgpassform').toggle("slow");
      if ($(this).val() == "Change Password") {
      $(this).val("Close");
      $('#y11').addClass("col-sm-6");
      $("#y11").removeClass("col-sm-12");
   }
   else {
      $(this).val("Change Password");
      $('#y11').addClass("col-sm-12");
   }
    });
    
   $('#ename').click(function(){
	   if($('#name').prop("disabled") ==true)
		   {
		   $('#name').prop("disabled", false);
		   $('#name').css('border','#28de28 2px solid');
		   }
	   else
		   {
		   $('#name').prop("disabled", true);
		   $('#name').css('border','rgb(206, 212, 218) 1px solid');
		   }
	   
   });
   $('#emob').click(function(){
	   if($('#mobile').prop("disabled") ==true)
		   {
		   $('#mobile').prop("disabled", false);
		   $('#mobile').css('border','#28de28 2px solid');
		   }
	   else
		   {
		   $('#mobile').prop("disabled", true);
		   $('#mobile').css('border','rgb(206, 212, 218) 1px solid');
		   }
	   
   });
   $('#eadd').click(function(){
	   if($('#address').prop("disabled") ==true)
		   {
		   $('#address').prop("disabled", false);
		   $('#address').css('border','#28de28 2px solid');
		   }
	   else
		   {
		   $('#address').prop("disabled", true);
		   $('#address').css('border','rgb(206, 212, 218) 1px solid');
		   }
	   
   });
});