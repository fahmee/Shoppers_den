package com.virtusa.shoppersden.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;


import com.virtusa.shoppersden.models.Product;
import com.virtusa.shoppersden.services.CategoryService;
import com.virtusa.shoppersden.services.ProductService;

@Controller
public class ProductController {

	@Autowired
	private ProductService productService;
	@Autowired
	private CategoryService categoryService;
    
	List<Product> allproduct=new ArrayList<Product>();
	
	List<String> productNameList=new ArrayList<String>();
	
	
	
	@GetMapping("/product")
	public String getAllProducts(Model model) {
		model.addAttribute("getproducts", productService.getAllProducts());
		model.addAttribute("getcategorities", categoryService.getAllCategories());
		return "admin/product";
	}

	@PostMapping("/addproduct")
	public String addProduct(@ModelAttribute Product product, @RequestParam(name = "category") int categoryId) {
		product.setImgURL("images/"+product.getImgURL());
		productService.addProduct(product, categoryId);
		return "redirect:/product";
	}

	@PostMapping("/updateproduct/{categoryId}")
	public Product updateProduct(@RequestBody Product product, @PathVariable int categoryId) {
		return productService.updateProduct(product, categoryId);
	}

	@PostMapping("/deleteproduct/{productId}")
	public void deleteProduct(@PathVariable int productId) {
		productService.deleteProduct(productId);
	}
	
	@SuppressWarnings("null")
	@GetMapping("/getproductbycategory/{categoryId}")
	public String getProductByCategory(@PathVariable int categoryId,Model model) {
		allproduct=productService.getAllProducts();
		
		List<Product> particularCategoryProduct = new ArrayList<Product>();
		
		for(Product product:allproduct)
		{
			
//			System.out.println(product.getImgURL());
//			System.out.println(product.getCategory().getCategoryId());
			if(product.getCategory().getCategoryId()==categoryId) 
			{
//			   if(!particularCategoryProduct.contains(product.getProductId())) {
//				   System.out.println("i M in");
				    particularCategoryProduct.add(product); 
				if(!productNameList.contains(product.getProductName()))
					productNameList.add(product.getProductName());
					//System.out.println(product.getProductName());
					
					
			}
		}
	    model.addAttribute("particularProduct",productNameList);
		model.addAttribute("particularCategory",particularCategoryProduct);
		return "allproduct";
		
		
	}
	
	
	  @GetMapping("/getProductBySubCategory/{name}") 
	  public String getProductBySubCategory(@PathVariable String name,Model model) {
	  //allproduct=productService.getAllProducts(); //List<Product>
	  //particularCategoryProduct = new ArrayList<Product>();
	  
	  List<Product> particularproductNameList=new ArrayList<Product>(); 
	  for(Product product:allproduct) {
               if(product.getProductName().equals(name)) 
	                  particularproductNameList.add(product);
	  }
	  model.addAttribute("particularProduct",productNameList);
	  model.addAttribute("particularCategory",particularproductNameList); 
	  return "allproduct";
	  
	  
	  }
	 

}
