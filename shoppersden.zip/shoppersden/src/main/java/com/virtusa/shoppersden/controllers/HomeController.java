package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.virtusa.shoppersden.services.CategoryService;
import com.virtusa.shoppersden.services.SecurityQuestionService;

@Controller
public class HomeController {
	
	@Autowired
	private SecurityQuestionService securityQuestionService;
	@Autowired
    private CategoryService categoryService;

	@GetMapping("/")
	public String Home(Model model)
	{
		System.out.println(categoryService.getAllCategories());
		model.addAttribute("allcategory",categoryService.getAllCategories());
	    return "index";
	}
	

	@GetMapping("/admin")
	public String adminHome()
	{
		return "admin/home";
	}
	
	@GetMapping("/login")
	public String userLogin(Model model)
	{
		model.addAttribute("message","Welcome to Login Page");
		return "login";
	}
	
	@GetMapping("/regisration")
	public String userRegistration(Model model)
	{  
		model.addAttribute("getAllQuestion", securityQuestionService.getAllQuestions());
		return "registration";
	}
	
	
	@GetMapping("/profile")
	public String profile()
	{
		return "profile";
	}
}
