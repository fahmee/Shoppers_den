package com.virtusa.shoppersden.models;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Shoppers_User")
public class User {
 
	@Id
	@Column(name = "Phone_Number", length = 10)
	private int phoneNumber;

	@Column(name = "User_Name", length = 40)
	private String userName;

	@Column(name = "Email", length = 40, unique = true, nullable = false)
	private String email;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "Question_Id", nullable = false)
	private SecurityQuestion securityQuestion;

	@Column(name = "Password", length = 150)
	private String password;

	@Column(name = "Address", length = 80)
	private String address;

	@Column(name = "Answer", length = 40)
	private String answer;

	@Column(name = "Enabled")
	private byte enabled;
	

	//@OneToMany(cascade = CascadeType.ALL, mappedBy = "user", fetch = FetchType.EAGER)
	//@JsonIgnoreProperties("user")
	//private List<UserRole> userRole;
	
	 @OneToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "Role_Id",columnDefinition="Decimal(10,0) default '1'") 
	 //@Column(columnDefinition="Decimal(10,0) default '1'")
	 private UserRole userRole;

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public SecurityQuestion getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(SecurityQuestion securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public byte getEnabled() {
		return enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
