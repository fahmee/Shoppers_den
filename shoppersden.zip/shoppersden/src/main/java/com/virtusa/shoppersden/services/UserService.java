package com.virtusa.shoppersden.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shoppersden.models.User;
import com.virtusa.shoppersden.models.SecurityQuestion;
import com.virtusa.shoppersden.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private SecurityQuestionService securityQuestionService;

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public User addUser(User user) {
		
//		SecurityQuestion question = securityQuestionService.findQuestionById(questionId);
//		user.setSecurityQuestion(question);
		return userRepository.save(user);
	}

	public User updateUser(User user, int questionId) {
		SecurityQuestion question = securityQuestionService.findQuestionById(questionId);
		user.setSecurityQuestion(question);
		return userRepository.save(user);
	}

	public boolean deleteUser(int userId) {
		boolean status = false;
		userRepository.deleteById(userId);
		status = true;
		return status;
		
	}
	
	public User getUser(int userid)
	{
		return userRepository.findById(userid).orElse(null);
	}
	
	public User resetUserPassword(User user) {
		//SecurityQuestion question = securityQuestionService.findQuestionById(questionId);
		//user.setSecurityQuestion(question);
//		
//		boolean status = false;
//		String password=user.getPassword();
//		user.setPassword(password);
		return userRepository.save(user);
		 
	}
	
	
}
