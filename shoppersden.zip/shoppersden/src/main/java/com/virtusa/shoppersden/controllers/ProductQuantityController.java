package com.virtusa.shoppersden.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.virtusa.shoppersden.models.ProductQuantity;
import com.virtusa.shoppersden.services.ProductQuantityService;

@RestController
public class ProductQuantityController {

	@Autowired
	private ProductQuantityService productQtyService;

	@GetMapping("/getproductquantities")
	public List<ProductQuantity> getAllProductQuantities() {
		return productQtyService.getAllProductQuantities();
	}

	@PostMapping("/addproductquantity")
	public ProductQuantity addProductQuantity(ProductQuantity productQty) {
		return productQtyService.addProductQuantity(productQty);
	}

	@PostMapping("/updateproductquantity")
	public ProductQuantity updateProductQuantity(ProductQuantity productQty) {
		return productQtyService.updateProductQuantity(productQty);
	}

	@PostMapping("/deleteproductquantity")
	public void deleteProductQuantity(int productQtyId) {
		productQtyService.deleteProductQuantity(productQtyId);
	}
}
