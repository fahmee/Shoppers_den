package com.virtusa.shoppersden.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.virtusa.shoppersden.models.SecurityQuestion;
import com.virtusa.shoppersden.services.SecurityQuestionService;

@Controller
public class SecurityQuestionController {

	@Autowired
	private SecurityQuestionService securityQuestionService;

	@GetMapping("/question")
	public String getAllQuestions(Model  model) {
			model.addAttribute("getquestions", securityQuestionService.getAllQuestions());
			return "admin/securityquestion";
		}

	@PostMapping("/addquestions")
	public String addSecurityQuestion(SecurityQuestion question) {
		 securityQuestionService.addQuestion(question);
		return "redirect:/question";
	}

	@PostMapping("/updatequestions")
	public SecurityQuestion updateSecurityQuestion(SecurityQuestion question) {
		return securityQuestionService.updateQuestion(question);
	}

	@PostMapping("/deletequestions")
	public void deleteSecurityQuestion(int questionId) {
		securityQuestionService.deleteQuestion(questionId);
	}
}
