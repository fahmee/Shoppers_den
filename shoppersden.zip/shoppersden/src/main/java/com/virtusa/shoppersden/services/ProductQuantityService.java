package com.virtusa.shoppersden.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shoppersden.models.ProductQuantity;
import com.virtusa.shoppersden.repository.ProductQuantityRepository;

@Service
public class ProductQuantityService {

	@Autowired
	private ProductQuantityRepository productQtyRepository;

	public List<ProductQuantity> getAllProductQuantities() {
		return productQtyRepository.findAll();
	}

	public ProductQuantity addProductQuantity(ProductQuantity productQty) {
		return productQtyRepository.save(productQty);
	}

	public ProductQuantity updateProductQuantity(ProductQuantity productQty) {
		return productQtyRepository.save(productQty);
	}

	public void deleteProductQuantity(int productQtyId) {
		productQtyRepository.deleteById(productQtyId);
	}
}
