package com.virtusa.shoppersden.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shoppersden.models.Cart;
import com.virtusa.shoppersden.repository.CartRepository;

@Service
public class CartService {

	@Autowired
	private CartRepository cartRepository;

	public List<Cart> getAllCarts() {
		return cartRepository.findAll();
	}

	public Cart getCartById(int cartId) {
		return cartRepository.findById(cartId).orElse(null);
	}

	public Cart addCart(Cart cart, int userId) {
		return cartRepository.save(cart);
	}

	public Cart updateCart(Cart cart, int userId) {
		return cartRepository.save(cart);
	}

	public void deleteCart(int cartId) {
		cartRepository.deleteById(cartId);
		;
	}

}
