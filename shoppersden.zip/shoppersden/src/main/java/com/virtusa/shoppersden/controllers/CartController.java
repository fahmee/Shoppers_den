package com.virtusa.shoppersden.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.shoppersden.models.Cart;
import com.virtusa.shoppersden.services.CartService;

@RestController
public class CartController {

	@Autowired
	private CartService cartService;

	@GetMapping("/getcarts")
	public List<Cart> getAllCarts() {
		return cartService.getAllCarts();
	}

	@PostMapping("/addcart")
	public Cart addCart(@RequestBody Cart cart, int userId) {
		return cartService.addCart(cart, userId);
	}

	@PostMapping("/updatecart")
	public Cart updateCart(@RequestBody Cart cart, int userId) {
		return cartService.updateCart(cart, userId);
	}

	@PostMapping("/deletecart")
	public void deletecart(int cartId) {
		cartService.deleteCart(cartId);
	}

}
