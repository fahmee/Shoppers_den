package com.virtusa.shoppersden.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.shoppersden.models.SecurityQuestion;
import com.virtusa.shoppersden.models.User;
import com.virtusa.shoppersden.services.CategoryService;
import com.virtusa.shoppersden.services.UserService;

@Controller
public class UserController {

	@Autowired 
	private UserService userService;
	
	@Autowired
	private CategoryService categoryService; 

	@GetMapping("/resetpasswordpage")
	public String resetHome() {
		 
		return "resetpassword";
		 //return userService.getAllUsers();
	}
	
	@GetMapping("/user")
	public String getAllUsers(Model model) {
		 model.addAttribute("getusers",userService.getAllUsers());
		return "admin/user";
		 //return userService.getAllUsers();
	}

//	@PostMapping("/adduser/{questionId}")
//	public User addUser(@RequestBody User user, @PathVariable int questionId) {
//		return userService.addUser(user, questionId);
//	} 
	
	@PostMapping("/adduser")
	public String addUser(@ModelAttribute User user) {
		
		String[] password=user.getPassword().split(",");
		if(password[0].equals(password[1]))
		{
			user.setPassword(password[0]);
			userService.addUser(user);
			return "login";
		}
		
		else
		    return "register";
	} 
	
	@PostMapping("/authenticateUser")
	public String auhenticateUser(@ModelAttribute User user,Model model,HttpSession session) {
		 
		String pass=user.getPassword();
		System.out.println(pass);
		int userid=user.getPhoneNumber();
		
		try {
			User user1=userService.getUser(userid);
			if(user1.getPassword().equals(pass))
			{
				model.addAttribute("allcategory",categoryService.getAllCategories());
//				session.setAttribute("userId", user1.getPhoneNumber());
//				session.setAttribute("username",user1.getUserName());
				return "index";
			}
			else
			{
				model.addAttribute("message","your password did not match");
				return "login";
				}
			
		} catch (Exception e) {
			model.addAttribute("message","YOUR PHONENO WAS WRONG");
			return "login";
		}
		
		//System.out.println(user1.getPassword());
		
		   
		} 
	
	@PostMapping("/getSecurityQuestion")
	public String getSecurityQuesion(@ModelAttribute User user,Model model) {
		
		try {
			int userid=user.getPhoneNumber();
			User user1=userService.getUser(userid);
			model.addAttribute("userQuestion",user1.getSecurityQuestion());
			//model.addAttribute("phonenumber", user.getPhoneNumber());
			model.addAttribute("user",user);
				return "useranswer";
		} catch (Exception e) {
			model.addAttribute("message","Your PhoneNo was  wrong");
		    return "login";
		}
		
		
		   
		} 
	
	@PostMapping("/matchSequertyAnswer")
	public String matchSequertyAnswer(@ModelAttribute User user,Model model) {
		System.out.println("===============================================================matchSequertyAnswer");
		
		int userid=user.getPhoneNumber();
		String formanswer=user.getAnswer();
		User user1=userService.getUser(userid);
		String userAnswer=user1.getAnswer();
		if(formanswer.equals(userAnswer))
		{  
			model.addAttribute("user",user);
			  return "resetpassword";
		}
		else {
			model.addAttribute("userQuestion",user1.getSecurityQuestion());
			model.addAttribute("user",user);
			model.addAttribute("message","Your answer was Wrong");
			
			return "useranswer";
			}
		
		   
		} 
	
	

	@PostMapping("/resetPassword")
	public String resetPassword(@ModelAttribute User user) {
		System.out.println("===============================================================resetpassword");
		//boolean status=false;
		int userId=user.getPhoneNumber();
		User user1=userService.getUser(userId);
		String[] password=user.getPassword().split(",");
		if(password[0].equals(password[1]))
		    user1.setPassword(password[0]);
		//user1.setPassword(password);
		//System.out.println(user.getEmail());
		userService.resetUserPassword(user1);
		
		//userService.resetUserPassword(password);
		return "login";
		   
		} 
	
	@PostMapping("/updateuser/{questionId}")
	public User updateUser(@RequestBody User user, @PathVariable int questionId) {
		return userService.updateUser(user, questionId);
	}
}
