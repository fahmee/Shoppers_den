package com.virtusa.shoppersden.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "User_Role")
public class UserRole {

//	@Id 
//	@ManyToOne(fetch = FetchType.EAGER,optional = false)
//	@JoinColumn(name = "User_Id")
//	//@JsonIgnoreProperties("userRole")
//	private User user;
//	@Column(name = "Role")
//	private String role;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "Role_Id")
	private int userRoleId;
	@Column(name = "ROLE", length = 15)
	private String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}

}